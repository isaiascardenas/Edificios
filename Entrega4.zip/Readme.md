# Edificios

Laboratorio nº4 métodos de programación

## Uso 

Primero se debe reescribir el archivo de entrada ubicado en esta carpeta: ListaMateriales.txt.
Dado que los archivos del programa ya fueron compilados solo hace falta ejecutar el archivo principal "Index.class", luego de eso el programa comenzará a pedir los datos correspondientes comenzando con los porcentajes. Las categorías de los porcentajes deben ser consistentes con las categorías en el archivo ListaMateriales.txt. Luego se solicitará el área que usará la torre el cual debe ser ingresado en el formato indicado en el enunciado ("m n"). Finalmente debe ingresar el presupuesto seguido del peso máximo que soporta el área indicada.

El programa realizará los cálculos he imprimirá los resultados torre por torre mostrando la cantidad y nombre de los materales necesarios para construir las torres. En caso de no ser posible construir alguna de ellas el programa lo indicará.

Isaías Cárdenas

