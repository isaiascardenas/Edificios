class Index {

	public static void main(String[] args) {
		Application app = new Application();
		app.run();
	}
}
